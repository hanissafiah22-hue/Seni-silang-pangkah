// Isi kedua-dua nilai daripada Supabase > Project Settings > API.
// Kunci publishable/anon sahaja. JANGAN masukkan service_role/secret key.
window.SUPABASE_URL = '';
window.SUPABASE_ANON_KEY = '';
