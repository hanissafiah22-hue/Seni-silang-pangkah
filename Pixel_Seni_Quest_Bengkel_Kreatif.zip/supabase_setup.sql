-- Jalankan dalam Supabase SQL Editor.
create table if not exists public.scores (
 id bigint generated always as identity primary key,
 nickname varchar(35) not null check (char_length(trim(nickname)) between 1 and 35),
 classroom varchar(30) not null default '',
 score integer not null check (score between 0 and 100 and score % 10 = 0),
 created_at timestamptz not null default now()
);
create index if not exists scores_created_at_idx on public.scores (created_at desc);
alter table public.scores enable row level security;
revoke all on public.scores from anon, authenticated;
grant insert on public.scores to anon;
grant select on public.scores to authenticated;
create policy "students may submit" on public.scores for insert to anon with check (true);
create policy "teacher reads scores" on public.scores for select to authenticated using (true);
-- Cipta HANYA akaun guru di Authentication > Users; matikan public signups.
-- Penyertaan murid tanpa log masuk: jangan gunakan nama penuh / data peribadi.
-- Polisi insert terbuka boleh menerima markah palsu; sesuai untuk aktiviti tidak rasmi sahaja.
